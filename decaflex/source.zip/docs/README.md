
Your documentation
------------------

decaflex meets all requirements and can correctly tokenize multiline comments
